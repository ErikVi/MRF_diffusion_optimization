"""diffusion scientific layer."""
