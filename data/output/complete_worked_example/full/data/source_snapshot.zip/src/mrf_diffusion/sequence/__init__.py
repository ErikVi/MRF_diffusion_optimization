"""sequence scientific layer."""
